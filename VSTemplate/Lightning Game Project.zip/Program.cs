﻿using LightningGL; // use lightninggl

//Lightning Visual Studio Template
//©2022 starfrost, August 13, 2022

// Use this to get started
// Initialise Lightning, this will run MainScene
Lightning.Init(args);
