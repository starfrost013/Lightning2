﻿// Lightning 2.0 Visual Studio template, January 29, 2023
//
// © 2022-2023 starfrost. All rights reserved.

// Initialise the client for this example, this will run MainScene
// this is in the LightningGL::Client class (included via a static global using)
Lightning.InitClient();
